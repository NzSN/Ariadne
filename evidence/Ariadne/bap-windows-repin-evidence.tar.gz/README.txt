Controlled Windows Crashpad replacement campaign.
The separate input archive retains the generated partial dump and matching executable for replay.
This derived archive retains build/capture/inspection, analyzer reports, samples, tests and source identities.
BAP model/mutation and Stage E records were reused after exact current inventory/tool checks.
Historical Priority4/I4 input was not replaced. See top-level timing flags before claiming full Stage1.
No Stage2 implementation is claimed.
