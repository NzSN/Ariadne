"""Freeze the controlled replacement campaign without rewriting earlier evidence."""
import hashlib
import io
import json
from datetime import datetime, timezone
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'tools'))
import check_bap_semantics as gate
import check_bap_model as model
import check_bap_mutations as mutations
import check_stage_e as stage_e


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


final = Path(sys.argv[1])
aggregate = read(final / 'report.json')
assert aggregate['passed'] and aggregate['sourcesStable']
assert aggregate['sourceHashes'] == gate.sources()
gate.validate_workload_bindings(aggregate['records']['workload'])
for key, module in [('model', model), ('mutation', mutations), ('stage-e', stage_e)]:
    assert aggregate['records'][key]['sourceHashes'] == module.sources()
assert aggregate['records']['model']['observerSha256'] == sha(ROOT / 'target/release/bap-model-case')
stage = aggregate['records']['stage-e']
assert stage['tools']['nativeIRSha256'] == sha(ROOT / 'target/ariadne-llvm-ir')
assert stage['tools']['nativeMCSha256'] == sha(ROOT / 'target/ariadne-llvm-mc')
assert stage['tools']['graphvizSha256'] == sha(stage['tools']['graphvizPath'])
case_path = ROOT / 'evidence/Ariadne/bap-windows-workload-case.json'
case = read(case_path)
input_archive = ROOT / case['inputArchive']['path']
assert sha(input_archive) == case['inputArchive']['sha256']
with tarfile.open(input_archive) as tar:
    assert {m.name for m in tar.getmembers()} == set(case['inputArchive']['entries'])
    for member in tar.getmembers():
        assert member.isreg()
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == case['inputArchive']['entries'][member.name]
capture, inspection, build = (read(BASE / p) for p in ['capture/capture.json', 'capture/inspection.json', 'build/build.json'])
assert inspection['passed'] and inspection['independently_decoded_starts'] == 98
assert capture['captureCreated'] and capture['uploadsEnabled'] is False and build['passed']
assert capture['dump']['sha256'] == case['capture']['sha256'] == inspection['inputs']['dump']['sha256']
assert sha(ROOT / case['replacement']['historicalManifest']) == case['replacement']['historicalManifestSha256']
for name, digest in case['provenance']['demoSourceHashes'].items():
    assert sha(ROOT / 'native/crashpad-demo' / name) == digest
for name, identity in inspection['local_source_files'].items():
    assert sha(ROOT / 'native/crashpad-demo' / name) == identity['sha256']
assert build['buildScriptSha256'] == sha(ROOT / 'native/crashpad-demo/build_windows.py')
assert sha(BASE / 'build/build.json') == capture['buildRecordSha256']

sources = dict(aggregate['sourceHashes'])
for path in (ROOT / 'native/crashpad-demo').iterdir():
    if path.is_file() and path.suffix != '.md':
        sources[str(path.relative_to(ROOT))] = sha(path)
test_path = ROOT / 'tools/test_crashpad_workload_inspector.py'
sources[str(test_path.relative_to(ROOT))] = sha(test_path)
record = dict(
    schema='ariadne.bap-windows-repin-validation/v1', recordedUtc=datetime.now(timezone.utc).isoformat(),
    passed=True, captureCreated=True, independentInspectionPassed=True, durablePinVerified=True,
    implementationGatesPassed=aggregate['implementationGatesPassed'],
    stage1ExitPassed=aggregate['stage1ExitPassed'],
    stage2PrerequisiteSatisfied=aggregate['stage2PrerequisiteSatisfied'],
    stage2Started=False, stage2Qualified=False,
    windowsWorkloadQualification=aggregate['windowsWorkloadQualification'],
    sourcesStable=True, sourceHashes=dict(sorted(sources.items())),
    activeCase=str(case_path.relative_to(ROOT)), activeCaseSha256=sha(case_path),
    inputArchive=case['inputArchive'],
    tests={'workloadDecisionTests': 59, 'independentInspectorTests': 9},
    records={'acceptance': aggregate, 'nativeBuild': build, 'capture': capture, 'inspection': inspection,
             'defaultProfileInspection': read(BASE / 'null-write-regression/inspection.json')},
    historicalPriority4Unchanged=True, historicalI4Repinned=False,
    measurementNotes=['CLI eligibility uses time.perf_counter_ns samples stored in cli.csv. Ancillary GNU time wall readings differ by about 0.70 and 0.73 seconds on measured runs 1 and 4; the clock discrepancy was not diagnosed. Both timing sets remain well above 2000 ms.'],
    scope='User-authorized controlled Crashpad replacement for active BAP Stage 1 only. passed records capture, pin and implementation success; Stage 1 timing eligibility is separate. Historical Electron evidence is preserved; no Stage 2 implementation.')

entries = {}


def add(path, name):
    assert name not in entries
    entries[name] = Path(path).read_bytes()


for path in sorted(final.glob('*')):
    if path.is_file():
        add(path, 'acceptance/' + path.name)
workload_log = (final / 'workload.log').read_text()
workload = Path(next(line[8:] for line in workload_log.splitlines() if line.startswith('Report: '))).parent
for path in sorted(workload.rglob('*')):
    if path.is_file() and path.suffix in ('.json', '.txt', '.dot', '.csv', '.time'):
        add(path, 'workload/' + str(path.relative_to(workload)))
for directory in ('build', 'capture', 'first-analysis', 'null-write-regression'):
    for path in sorted((BASE / directory).iterdir()):
        if path.is_file() and path.suffix in ('.json', '.log', '.txt', '.dot', '.ensure'):
            add(path, directory + '/' + path.name)
for name in ('acceptance.log', 'workload-tests.log', 'inspector-tests.log', 'model-current.json',
             'mutation-current.json', 'stage-e-current.json', 'first-analysis.log', 'retain.py'):
    add(BASE / name, name)
for path in sorted((ROOT / 'native/crashpad-demo').iterdir()):
    if path.is_file() and path.suffix != '.md':
        add(path, 'sources/native/crashpad-demo/' + path.name)
add(test_path, 'sources/tools/test_crashpad_workload_inspector.py')
add(case_path, 'active-case.json')
for path in sorted(Path('/tmp/ariadne-bap-asm-verified').iterdir()):
    if path.is_file():
        add(path, 'assembler-proof/' + path.name)
origin = ROOT / 'evidence/Ariadne/bap-windows-workload-evidence-manifest.json'
origin_data = read(origin)
assert sha(origin.parent / origin_data['archive']) == origin_data['sha256']
assert sha(origin.parent / origin_data['validationRecord']) == origin_data['validationRecordSha256']
entries['reused-origin.json'] = (json.dumps({
    'originManifest': str(origin.relative_to(ROOT)), 'originManifestSha256': sha(origin),
    'originArchiveSha256': origin_data['sha256'],
    'reused': 'BAP model, BAP mutations and Stage E; complete current inventories and applicable observer/native tool identities verified.'
}, indent=2) + '\n').encode()
entries['README.txt'] = b'''Controlled Windows Crashpad replacement campaign.
The separate input archive retains the generated partial dump and matching executable for replay.
This derived archive retains build/capture/inspection, analyzer reports, samples, tests and source identities.
BAP model/mutation and Stage E records were reused after exact current inventory/tool checks.
Historical Priority4/I4 input was not replaced. See top-level timing flags before claiming full Stage1.
No Stage2 implementation is claimed.
'''
dest = ROOT / 'evidence/Ariadne'
record_path = dest / 'bap-windows-repin-validation.json'
record_path.write_text(json.dumps(record, indent=2) + '\n')
add(record_path, 'validation.json')
archive = dest / 'bap-windows-repin-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, data in sorted(entries.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
manifest = dict(schema='ariadne.evidence-manifest/v1', archive=archive.name,
                sha256=sha(archive), bytes=archive.stat().st_size,
                validationRecord=record_path.name, validationRecordSha256=sha(record_path),
                sourceInventoryCount=len(sources), inputArchive=case['inputArchive'],
                entries={name: hashlib.sha256(data).hexdigest() for name, data in sorted(entries.items())})
with tarfile.open(archive) as tar:
    assert {m.name for m in tar.getmembers()} == set(entries)
    for member in tar.getmembers():
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == manifest['entries'][member.name]
(dest / 'bap-windows-repin-evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Retained', len(sources), 'source hashes;', len(entries), 'verified derived entries;', archive.stat().st_size, 'bytes')
print(json.dumps(record['windowsWorkloadQualification']))
