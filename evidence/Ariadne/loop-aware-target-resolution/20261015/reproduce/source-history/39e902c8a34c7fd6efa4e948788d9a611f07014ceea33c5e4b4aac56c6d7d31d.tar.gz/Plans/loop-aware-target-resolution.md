# Loop-aware extension of the existing target resolver

## Context and follow-up

**Status.** Designed 2026-10-15; implementation and qualification have not started. L0–L6 below extend the existing resolver with checked local-region induction. No loop capability is accepted by this document.

**Why this document exists.** The [canonical composition design](../docs/Ariadne/guarded-target-resolution-design.md#proposed-stable-base-invariant-follow-up) owns this extension's contracts. The [C0–C6 parent plan](guarded-target-resolution.md) retains the ninth incoming-coverage clause after successful candidate recovery.

**What this document establishes.** The support boundary, reviewable implementation stages, file ownership, dependencies and remote acceptance gates for closing the DA09/DADD cyclic dispatch certificates.

**Where to go next.** Read the canonical design's loop section first, then L0 for exact proof/codec/budget decisions and L6 for the required dump outcome. The [retained qualification](../evidence/Ariadne/guarded-target-resolution/20261014/README.md) supplies the baseline; the [formal-model guide](../Specs/README.md) defines model authority.

**What remains unresolved.** Every L stage remains pending. The callee's other indirect jumps and work residuals, caller semantic barriers, MOVAPS admission, call-anchor recovery and full frame paths remain separate gates. Larger SCCs and general loop synthesis are outside this first scope.

## Objective and design decision

Extend the current resolver with a private loop-closure proof module. Reuse `relative32` evaluation and one materialization coordinator. For a small local dispatch region, prove a stable table base, permit changing RCX and fresh selector loads, and establish the selector domain before each indexed table load. Produce a whole-dispatch induction receipt checked independently by Rust and native admission.

This is a design-and-plan delivery only. It authorizes no claim that a code change or new dump result exists. Implementation should execute the gates below without replacing unknown controls, adding roots or importing crash-time values into earlier states.

## Baseline and concrete dump acceptance

| Baseline item | Retained value |
| --- | --- |
| Dump | `dump_03958DA4FCA844A786262A1053` |
| Dump SHA-256 | `9be21e47453fec954857db52db7dfe3b8c5a5c6a49369d39a10eb701de9624ab` |
| Query | Thread 23668, frame pair 1 → 0, NP10 |
| Caller candidate epoch / sites | 610 / 9,590 |
| Candidate identity | `composition.candidate_sha256=50b54d681fe01f9488da4cf2c90948afe52cb2ab13dad2e960bad55648122a3f` |
| Target status | Eight original complete certificates; DA09 and DADD each have four known targets and `cyclic-incoming-state` |
| Discovery | Nine original table sets reconciled; 64 destinations, all 51 formerly missing starts attempted |
| Final result | Rust/native requests and full states match; caller MOVAPS unknown; frame listing unavailable |

The maximal SCCs contain 4,694 and 411 nodes and many base clobbers/calls. Initial support must instead discover and verify the following local regions. Instruction offsets below share the explicit semantic VA prefix `0x00007ff77440`:

```text
DA09 region: d9eb d9ee d9f1 d9f7 d9fc da00 da02 da06 da09
DADD region: dabf dac2 dac5 dacb dad0 dad4 dad6 dada dadd

Entrance / base-reset corridor:
  d9e2 LEA RDX,base → d9e9 JMP → d9f7
  dab6 LEA RDX,base → dabd JMP → dacb

Each local region: 9 nodes; 10 internal edges; 1 entrance; 4 exits.
```

These are fixture expectations, never address-specific production rules. The canonical design records the table bases, original bytes and complete obligation structure. L0 must independently reproduce these facts from the sealed baseline and retain them as test fixtures. Structural feasibility is not a completed induction proof; rejected reverse contexts were not fully recorded by the old implementation.

## Implementation architecture

```text
Existing local resolver and coordinator
  → existing path/frontier/infeasible rules
  → private loop-region discovery and assertion proposal
  → independent loop-receipt validation
  → existing captured table evaluation / candidate union
  → discovery and epoch revalidation
  → paired native admission and reports
```

Keep ordinary path receipts unchanged. The new v3 local report uses a tagged coverage choice: existing prefix-tree coverage or a whole-dispatch inductive receipt. An inductive receipt checks every entrance and internal edge, derives all table successors without trusting current target-completeness flags, and preserves every exit. It is not a stable-load infeasibility receipt or an arbitrary-register frontier.

The private module returns `NotApplicable`, `Candidate{receipt,table_witnesses}` or `Partial{reason}`. A candidate cannot set `complete=true` until the shared validator accepts all required obligations on the final epoch. New target discoveries invalidate region/boundary proofs and restart checked closure. One context's first successful witness cannot erase other incoming alternatives.

## Stages, ownership and dependencies

Owners describe independent responsibilities for execution, not changes made by this plan. Workers are not alone in the checkout: preserve unrelated changes, edit only assigned files and coordinate shared interfaces before implementation. L0 freezes the interface and receipt contract before L2/L3 proceed in parallel. Review gates are evidence gates, not additional user-confirmation steps.

| Stage / owner | Principal files and tasks | Depends on | Reviewable exit |
| --- | --- | --- | --- |
| **L0 — Contract and baseline owner** | Update canonical design; preserve this plan; extract source-bound loop fixtures into `tests/bap/fixtures/loop-closure/`; record graph policy, regions, entrances, LEA corridors, original BIL/bytes, tables and baseline hashes. Freeze new coverage tag, full wire fields, private interface, version-indexed legacy validation contract and finite work units. | Source inspection | Independent reproduction of both local regions and all entrances; frozen legacy source/model identities; explicit rejection of the maximal-SCC invariant; no production address constants or expected-target injection. |
| **L1 — Formal model and oracle owner** | Add planned `Specs/AriadneLoopTargetClosure.tla`, finite configs and checker; integrate its coverage case with `AriadneTargetResolution.tla` and composition authority. Add an independent finite oracle under the fixture directory. Do not encode production matcher/substitution as the oracle. | L0 | Initialization, preservation, domain implication, every entrance/edge/exit, stale-epoch invalidation, conservative partial publication and bounded analyzer termination are modeled. Positive and deliberate counterexample configurations behave as specified. |
| **L2 — Rust resolver owner** | `src/bap/target_resolution.rs`; private implementation under `src/bap/target_resolution/`; strict receipt types; `tests/bap/target_resolution_unit.rs`; `src/bin/target_resolution_validate.rs` as necessary. Add bounded region discovery, point assertions and independent replay from original BIL. | L1 contract/model cases | Both synthetic loop shapes yield accepted whole-dispatch evidence. Replay rejects bad entrances, clobbers, wrong guard provenance and tampered boundaries. Existing target/frontier/infeasible/cycle tests retain their stated behavior. |
| **L3 — Native admission owner** | `native/bap-core/capture.ml`, `composition.ml`, `main.ml`, `build.py`; relevant `src/bap/core_adapter.rs`, `core_protocol.rs`, `core_session.rs` interfaces coordinated with L2. Add independent assertion/edge/read replay, new capability/profile handling and version-indexed legacy/new ruleset/model identities. | L1 and frozen L2 wire contract | Native accepts the same valid proof cases and rejects named invalid ones. Old helpers explicitly reject the new profile. Legacy proof replay retains its frozen contract separately from the new helper build identity. JSON field order cannot change symbolic equality. Exact read contributors and original BIL remain mandatory. |
| **L4 — Integration and reports owner** | `src/input/materialize.rs`; `src/bap/composition.rs`; input frame/report/investigation codecs, `src/reports/`, CLI and consumer tests. Integrate proof invalidation, target union, completeness-only epoch changes, dedicated v1 replay, saved old/new versions and JSON/text/DOT explanations. | L2 + L3 | One coordinator and immutable query scope; new targets queued without roots; summaries rechecked after epoch changes; no proof stripping or unsupported fallback. Validate actual retained 2026-10-14 combined minidump/frame reports without rewriting their model/checker identities; old/new roundtrips preserve full requests and gaps. |
| **L5 — Qualification owner** | Loop oracle/tests, targeted mutation tooling, isolated native SDK/helper/replay outputs, model logs and a new source/tool manifest under `evidence/Ariadne/loop-aware-target-resolution/`. | L4 | Applicable root checks, model/oracle controls, native admission, saved-report controls, behavioral mutations and generated replay pass on the same source snapshot. Missing prerequisites remain unexercised rather than passed. |
| **L6 — Original-dump and delivery owner** | Byte-identical dump retry, all-nine table reconciliation, DA09/DADD proof comparison, native/Rust full-state parity, remaining-barrier report; update canonical dated validation and parent C5 status. | L5 | Both dispatches complete with the expected four-target sets and validated induction receipts; eight previously complete certificates retain valid coverage; all original candidates remain. Separate frame-path result and remaining barriers are reported honestly. |

## L0 decisions to freeze before runtime edits

1. **Region rule:** bounded local phase discovery from actual table/control structure and definition boundaries; exact independent enumeration of all crossing/internal edges. Maximal SCCs may guide discovery but are not automatically proof regions.
2. **Entrance rule:** a checked base-reset assignment plus a fully covered acyclic corridor establishes the assertion for arbitrary earlier scalar state. A bypass into the corridor or an additional region entrance must be represented and proved.
3. **Assertions:** width-aware `Top`, constant, unsigned interval and finite set; same-iteration compare/flag/selector definition provenance. Unknown pointer loads and byte loads are fresh abstract values, with no inferred cross-iteration equality.
4. **Proof representation:** retain old path witnesses and add `ExistingPrefixTree | InductiveDispatch` coverage. The first loop rule covers the entire queried dispatch; arbitrary prefix summary application is deferred.
5. **Wire identity:** local target report v3/profile local-v2; combined native profile v2; composition v2; combined minidump v5, explanation v4 and frame-path v4. Preserve target-only v1, guard-only behavior and a dedicated semantic replay path for legacy combined reports. Freeze old Rust/model source bytes as hash-verified fixture assets before edits; select checker semantics and admitted proof identities by version, separately from the new helper build identity. New loop-capable producers use new identities even when a loop proof declines.
6. **Budget accounting:** use existing target-limit fields; charge every nested scan, transfer/inclusion and finite-set operation; preserve zero limits and unchanged global defaults. Define producer and validator work accounting separately, including region edges, assertion sizes and report decoding.
7. **Proof independence:** replay original source BIL, captured bytes/control and table reads. Do not accept a producer's asserted constant, region boundary, domain, successful convergence flag or existing `complete` bit as its own evidence.

## Required positive and negative controls

| Family | Positive controls | Required rejection or partial controls |
| --- | --- | --- |
| Region and entrances | Both nine-node phase regions; base clobbers elsewhere in the large SCC do not poison a valid locally reinitialized phase; multiple independently initialized entrances | Hidden entrance, corridor bypass, root inside region without proof, omitted edge/exit, incorrect region contraction |
| Induction | Stable base with changing RCX; any number of pointer-loop and range-loop traversals; selector values vary across iterations | Base clobbered on one edge, different base on one entrance, circular reliance on candidate completeness, omitted recurrence |
| Branch constraints | MOVZX byte domain and unsigned JA untaken edge prove `0..9` at the table load | Wrong polarity, signed comparison, flag clobber, selector overwritten after comparison, applying the selector bound to target-valued R8 |
| Loads and effects | Fresh byte/pointer values, captured signed32 table arithmetic, existing stable-load infeasible receipts preserved | Equating different iterations' loads; original store or hidden pending-store BIL; opaque call; unknown memory write; unsupported relevant transfer |
| Captured evidence | All ten required selector slots with exact bytes/contributors and four derived destinations | Missing/conflicting slot, bad sign extension or wrap arithmetic, wrong base/slot/width, omitted table successor |
| Identity and consumers | Same sealed scope/epoch across producer, Rust, native and saved report; actual retained v1 combined minidump/frame semantic replay; valid old/new codec cases | Altered snapshot/activation/roots/semantics/epoch, swapped source AST, stripped closure, new loop evidence submitted under a legacy profile/hash, unsupported profile downgrade, malformed/extra fields |
| Resources and termination | Finite admitted region and independent receipt checking; runtime loop need not terminate | Zero step/value/time allowance, producer and native budget exhaustion, oversized assertions/evidence, nested uncharged work |

Use an independent small finite state space to enumerate one-step transfer inclusion and generate induction counterexamples. Finite oracle cases do not establish a universal Rust theorem. Mutations must independently disable entrance checking, base preservation, branch provenance, successor coverage, selector freshness or epoch binding. Credit requires a passing original and a named behavioral negative; compile errors, timeouts and rejection by an unrelated still-active check receive no behavioral mutation credit.

## Remote validation and evidence commands

All Cargo, native helper/SDK compilation, Apalache/TLC, replay, mutations and original-dump execution run on remote `windows-dev` WSL through the established `r_windev` workflow. Source inspection and document checks may run locally. Synchronize an exact source snapshot, verify archive/source/tool hashes and use a task-private checkout. Keep replay and mutation SUT build directories isolated under their checkout's `target/`.

The following existing root commands must pass in that remote checkout after implementation:

```sh
cargo fmt --all -- --check
cargo test --offline --locked
cargo test --offline --locked --no-default-features
cargo clippy --offline --locked --all-features --all-targets -- -D warnings
python3 tools/check_rust_layout.py
python3 tools/check_doc_links.py
bash Specs/check-target-resolution.sh
bash Specs/check-guarded-target-resolution.sh
python3 tests/bap/fixtures/composition/oracle.py --check
```

L1 must create and verify the new loop-model/oracle entry points. L5 records exact invocations of the existing target-resolution, native/frame, replay and mutation tools after inspecting their current options; do not present a planned script or guessed flag as an existing executable command. Include the affected ignored native tests, strict target validator, both completion codecs, actual dump receipt replay and legacy capability controls. Use dedicated outputs such as `target/loop-aware-native`, `target/loop-aware-replay-build` and `target/loop-aware-mutations-build`; adapt any tool with a fixed build path or isolate its whole SUT checkout.

Future evidence must retain source and tool hashes, model files/configs, helper manifests, exact budgets, stdout/stderr, original and mutated variants, failed attempts, original dump/PDB provenance when symbols are used, all capture-read witnesses, prospective/final graph identities and native/Rust comparison results. Preserve the old 2026-10-14 artifacts byte-for-byte as historical results.

## Acceptance and stopping rules

- L0–L1 deliver a reviewed contract and finite expectation set; they do not claim implementation.
- L2–L4 cannot publish completeness from an unvalidated summary or weaken legacy path-cycle checks globally. A failed summary preserves candidates and an explicit residual.
- L5 is accepted only for its exercised source/tool/model/corpus scope. Core-only builds retain no activated external crate dependencies.
- L6 must freshly establish both `0x00007ff77440da09` and `0x00007ff77440dadd` as complete, with their four expected targets, accepted Rust/native induction evidence and all-nine reconciliation. Re-run both frame queries and compare complete normalized requests and states.
- Report remaining caller/callee barriers and NP10 availability independently. A still-unavailable listing does not fail this narrower loop-closure gate; neither does successful target closure satisfy full frame-path acceptance.
- Update the parent ninth C5 clause only after the original-dump gate passes. Do not archive either active plan as full delivery merely because candidate recovery or finite tests pass.

## Validation of this plan document

This change is documentation only. Source inspection and independent semantic/qualification reviews informed the region, induction and version decisions. Local link/navigation and whitespace checks must pass before presenting the plan. No Cargo, native/model build, replay, mutation or dump retry is part of this planning turn.
