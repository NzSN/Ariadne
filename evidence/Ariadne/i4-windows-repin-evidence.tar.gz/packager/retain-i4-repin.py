from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile,shutil,sys,importlib.util
root=Path('/home/nzsn/Repos/Ariadne');sys.path.insert(0,str(root/'tools'))
from investigation_windows_case import CASE_RELATIVE,INSPECTION_RELATIVE,ARCHIVE_RELATIVE,load_case,case_digest
import check_investigation as inv,measure_investigation as measure
from with_mirrorrust_snapshot import active_identity
spec=importlib.util.spec_from_file_location('retainer','/tmp/retain-i5a-native-evidence.py');pack=importlib.util.module_from_spec(spec);spec.loader.exec_module(pack)
sha=pack.sha
work=root/'target/i4-windows-repin-retained';work.mkdir(exist_ok=False)
ap=Path('/tmp/ariadne-investigation-acceptance-c_xvrz_v/report.json');mp=Path('/tmp/ariadne-investigation-workload-5ow52zvh/report.json');a=json.loads(ap.read_text());m=json.loads(mp.read_text());case=load_case()
assert a['passed'] and a['sourcesStable'] and a['sourceHashes']==inv.sources()
assert m['passed'] and m['sourcesStable'] and m['sourceHashes']==measure.sources() and m['toolsStable']
assert a['activeWindowsCaseDigest']==m['windowsCaseDigest']==case_digest(case)
assert a['qualificationEnvironment']==m['qualificationEnvironment']==active_identity()
assert a['windows98Qualification']==m['windows98Qualification'] and a['windows98Qualification']['valid']
for name,digest in m['tools'].items():assert sha(root/name)==digest
c=pack.Collector();c.add(Path(__file__),'packager/retain-i4-repin.py')
sources={**a['sourceHashes'],**m['sourceHashes']}
for name,digest in sources.items():c.add(root/name,'sources/'+name,digest)
for path,name in [(ap,'records/investigation.json'),(mp,'records/measurement.json'),(root/CASE_RELATIVE,'records/active-case.json'),(root/INSPECTION_RELATIVE,'records/inspection.json'),(root/'evidence/Ariadne/priority-4-real-capture-case.json','historical/original-case.json')]:c.add(path,name)
roots=pack.discover_temp_roots(ap,c);c.add_artifact_tree(mp.parent,'measurements')
replay=pack.stage_e_replay_root({'records':{'investigation':a}});c.add_artifact_tree(replay,'replay/'+replay.name)
record={'schema':'ariadne.i4-windows-repin-validation/v1','recordedUtc':datetime.now(timezone.utc).isoformat(),'repinPassed':True,'implementationGatesPassed':a['passed'],'fullI4RealCaptureAcceptance':a['fullI4RealCaptureAcceptance'],'originalWindowsCaseExercised':False,'activeCaseId':case['id'],'activeCaseDigest':case_digest(case),'activeCaseManifestSha256':sha(root/CASE_RELATIVE),'captureSha256':case['capture']['sha256'],'query':case['query'],'decodedStarts':98,'windowsQualification':a['windows98Qualification'],'qualificationEnvironment':active_identity(),'sourceHashes':sources,'tools':m['tools'],'records':{'investigation':a,'measurement':m},'recordHashes':{'investigation':sha(ap),'measurement':sha(mp)},'scope':'User-authorized replacement of the active Windows I4 capture. Correctness and timing decisions remain separate; original Electron evidence is historical and unexercised.'}
report=work/'report.json';report.write_text(json.dumps(record,indent=2)+'\n');c.add(report,'records/repin.json')
archive=work/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,(path,_,_) in sorted(c.entries.items()):t.add(path,arcname=name,recursive=False)
pack.verify_archive(archive,c.entries)
manifest={'schema':'ariadne.i4-windows-repin-evidence/v1','verified':True,'archive':'i4-windows-repin-evidence.tar.gz','sha256':sha(archive),'bytes':archive.stat().st_size,'validationRecordSha256':sha(report),'entries':{n:d for n,(_,d,_) in c.entries.items()},'originalPaths':c.original_paths,'scope':record['scope']}
(work/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
b=root/'evidence/Ariadne'
for source,name in [(report,'i4-windows-repin-validation.json'),(archive,'i4-windows-repin-evidence.tar.gz'),(work/'manifest.json','i4-windows-repin-evidence-manifest.json')]:
 assert not (b/name).exists();shutil.copyfile(source,b/name);assert sha(source)==sha(b/name)
print('Repin retained; entries',len(c.entries),'bytes',manifest['bytes'],'full I4',record['fullI4RealCaptureAcceptance'])
