#!/usr/bin/env python3
import json,os,sys
with open(os.environ["SPEC_SYNC_COMMAND_LOG"],"a") as f:f.write(json.dumps(sys.argv[1:])+"\n")
raise SystemExit(7 if os.environ.get("SPEC_SYNC_FAIL_MODULE") in sys.argv[1:] else 0)
