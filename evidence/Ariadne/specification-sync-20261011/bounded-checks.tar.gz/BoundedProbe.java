import tlc2.tool.*;
import tlc2.tool.impl.*;
import tlc2.module.Json;
import tlc2.value.impl.StringValue;
import util.SimpleFilenameToStream;
public class BoundedProbe {
  public static void main(String[] args) throws Exception {
    if (args[0].equals("config")) {
      new ModelConfig(args[1], new SimpleFilenameToStream()).parse();
      System.out.println("CONFIG_PASS"); return;
    }
    FastTool tool = new FastTool(args[1], args[2], new SimpleFilenameToStream());
    StateVec initial = tool.getInitStates();
    if (initial.size()!=1) throw new AssertionError("initial state count");
    TLCState state=initial.elementAt(0); int count=0;
    while (true) {
      for (Action inv:tool.getInvariants())
        if (!tool.isValid(inv,state)) throw new AssertionError("invariant "+inv.getName());
      if (args[0].equals("expression")) {System.out.println("EXPRESSION_PASS");break;}
      boolean force = args[0].equals("external") && ((StringValue)state.lookup("phase")).val.toString().equals("process");
      TLCState selected=null;
      for (Action action:tool.getActions()) {
        if (args[0].equals("external") && action.getName().toString().equals("ExternalStop")!=force) continue;
        StateVec next=tool.getNextStates(action,state);
        for (int index=0; index<next.size(); index++) {
          TLCState candidate=next.elementAt(index);
          if (selected!=null && !selected.toString().equals(candidate.toString()))
            throw new AssertionError("nondeterministic selected trace\n"+selected+"\n"+candidate);
          selected=candidate;
        }
      }
      if (selected==null) {
        System.out.println("RESULT "+Json.toJson(state.lookup("listed")).val.toString());
        System.out.println("STOP "+Json.toJson(state.lookup("stop")).val.toString());
        System.out.println("BLOCKED "+Json.toJson(state.lookup("blocked")).val.toString());
        System.out.println("WORK "+Json.toJson(state.lookup("work")).val.toString());
        System.out.println("SCANS "+Json.toJson(state.lookup("scans")).val.toString());
        System.out.println("TRACE_PASS "+count);break;
      }
      state=selected;if(++count>128)throw new AssertionError("bounded probe exceeded 128 transitions");
    }
  }
}
