from pathlib import Path
import itertools,json,subprocess,time
work=Path(__file__).resolve().parent;models=work/'models';cp=str(work)+':/usr/local/lib/tla2tools.jar';records=[]
def run(name,mode,model,config):
    started=time.monotonic();command=['java','-Xmx128m','-cp',cp,'BoundedProbe',mode,str(models/model),str(models/config)]
    result=subprocess.run(command,cwd=models,capture_output=True,text=True,timeout=30)
    (work/(name+'.log')).write_text(result.stdout+result.stderr)
    assert result.returncode==0,(name,(result.stdout+result.stderr)[-3000:])
    records.append({'name':name,'command':command,'exit':0,'seconds':round(time.monotonic()-started,3)})
    return result.stdout
base=(models/'FramePaths.cfg').read_text()
variants={
'default':({},2,'path-count-budget'),
'loop-all':({'NP = 3':'NP = 8'},5,'search-restriction'),
'acyclic':({'EdgeOrder <- DemoEdges':'EdgeOrder <- DemoAcyclicEdges','NP = 3':'NP = 8'},3,'frontier-exhausted'),
'count-one':({'NP = 3':'NP = 1'},0,'path-count-budget'),
'work-zero':({'MaxWork = 20':'MaxWork = 0'},0,'search-state-budget'),
'scans-zero':({'MaxScans = 40':'MaxScans = 0'},0,'search-restriction'),
'steps-zero':({'MaxSteps = 6':'MaxSteps = 0'},0,'path-or-visit-budget'),
'visits-zero':({'MaxVisits = 2':'MaxVisits = 0'},0,'path-or-visit-budget'),
'deadline-zero':({'DeadlineAt = 21':'DeadlineAt = 0'},0,'deadline-budget'),
'same-endpoint':({'Start = 1':'Start = 4'},1,'frontier-exhausted'),
'external-after-pop':({'AllowExternalStops = FALSE':'AllowExternalStops = TRUE'},0,'external-resource-budget'),
'open-graph':({'EdgeOrder <- DemoEdges':'EdgeOrder <- DemoAcyclicEdges','NP = 3':'NP = 8','GraphComplete = TRUE':'GraphComplete = FALSE'},3,'frontier-exhausted'),
'no-path':({'EdgeOrder <- DemoEdges':'EdgeOrder <- EmptyEdges'},0,'frontier-exhausted'),
}
edges=[(1,2,'taken'),(1,2,'fallthrough'),(1,3,'next'),(2,2,'jump'),(2,4,'next'),(3,4,'next')]
words=[]
for n in range(6):
    for word in itertools.product(range(len(edges)),repeat=n):
        nodes=[1];ok=True
        for i in word:
            if edges[i][0]!=nodes[-1]:ok=False;break
            nodes.append(edges[i][1])
        if ok and nodes[-1]==4 and all(nodes.count(x)<=2 for x in set(nodes)):words.append(word)
words.sort();assert len(words)==5
for name,(replacements,count,reason) in variants.items():
    text=base
    for old,new in replacements.items():text=text.replace(old,new)
    config='probe-'+name;(models/(config+'.cfg')).write_text(text)
    output=run('frame-'+name,'external' if name.startswith('external') else 'trace','FrameSyncProbe',config)
    rows={line.split(' ',1)[0]:line.split(' ',1)[1] for line in output.splitlines() if line.startswith(('RESULT ','STOP ','BLOCKED ','WORK ','SCANS '))}
    result=json.loads(rows['RESULT']);assert len(result)==count and json.loads(rows['STOP'])==reason,(name,rows)
    if name in ('default','loop-all'):
        actual=[tuple(edges.index((e['src'],e['dst'],e['kind'])) for e in p['edges']) for p in result]
        assert actual==words[:count],(name,actual,words[:count])
    if name=='loop-all':assert len({tuple(p['nodes']) for p in result})<len(result)
    if name=='external-after-pop':assert json.loads(rows['WORK'])==1 and json.loads(rows['BLOCKED'])
print('Bounded frame trace probes PASS:',len(variants),'cases',flush=True)
cases=[]
def fact(kind='exact',value=2,mask=15,ops=()):return (kind,mask,value,ops)
for kind in ['copy','add','sub','and','constant']:cases.append((fact(),kind,1,None))
cases += [(fact(value=0),'and',0,None),(fact(value=2),'and',3,None),(fact(value=3),'constant',3,None)]
for kind in ['copy','add','sub','and','constant']:cases.append((fact('unknown',0,0),kind,1,'no-useful-numerical-constraint'))
plain=fact('constrained',2,3);composed=fact('constrained',2,3,(('add',1),));cap=fact('constrained',1,1,(('add',1),('sub',15)))
cases += [(plain,'copy',0,None),(plain,'add',1,None),(composed,'and',15,None),
(composed,'and',3,'unsupported-constraint-composition'),(composed,'and',0,'unsupported-constraint-composition'),
(cap,'add',1,'constraint-expression-budget'),(cap,'copy',0,None),(composed,'constant',1,None),(composed,'constant',2,None)]
def apply(kind,x,c):return {'copy':lambda:x,'add':lambda:(x+c)%16,'sub':lambda:(x-c)%16,'and':lambda:x&c,'constant':lambda:c}[kind]()
def permits(f,x):
    kind,mask,value,ops=f
    if kind=='unknown':return True
    if kind=='exact':return x==value
    for k,c in ops:x=apply(k,x,c)
    return x&mask==value
def tla_fact(f):
    kind,mask,value,ops=f
    return 'Fact('+json.dumps(kind)+','+str(mask)+','+str(value)+',<<'+','.join('Transfer('+json.dumps(k)+','+str(c)+')' for k,c in ops)+'>>)'
assertions=[]
for f,k,c,boundary in cases:
    pre={x for x in range(16) if permits(f,apply(k,x,c))}
    unrepresented=boundary in ('unsupported-constraint-composition','constraint-expression-budget')
    represented=not unrepresented and bool(pre);conflict=not pre and not unrepresented
    reason=boundary or ('inconsistent-predecessor-constraints' if conflict else 'information-erasure' if pre==set(range(16)) and k in ('constant','and') else '')
    before=pre if represented else set();expr='Inverse('+tla_fact(f)+',Transfer('+json.dumps(k)+','+str(c)+'))'
    assertions.append('  /\\ (LET r == '+expr+' IN /\\ r.after = '+tla_fact(f)+' /\\ r.represented = '+str(represented).upper()+' /\\ r.before = {'+','.join(map(str,sorted(before)))+'} /\\ r.conflict = '+str(conflict).upper()+' /\\ r.boundary = '+json.dumps(reason)+')')
probe='---------------- MODULE MemorySyncProbe ----------------\nEXTENDS AriadneMemoryRefinement\nProbeSafety ==\n'+'\n'.join(assertions)+'\n  /\\ CandidateSafety\n  /\\ ~Disjoint(15,4,1,2) /\\ Disjoint(15,4,8,2)\n========================================================\n'
(models/'MemorySyncProbe.tla').write_text(probe);(models/'MemorySyncProbe.cfg').write_text('INIT Init\nNEXT Next\nINVARIANT ProbeSafety\nCHECK_DEADLOCK FALSE\n')
run('memory-expression','expression','MemorySyncProbe','MemorySyncProbe')
print('Scalar preimage/boundary probes PASS:',len(cases),'cases; candidate and wrap controls',flush=True)
(work/'bounded-probes.json').write_text(json.dumps({'frameCases':len(variants),'scalarCases':len(cases),'records':records,'exhaustiveStateExploration':False,'remoteQualification':False},indent=2)+'\n')
