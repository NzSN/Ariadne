---------------- MODULE FrameSyncProbe ----------------
EXTENDS AriadneFramePaths
EmptyEdges == <<>>
======================================================
