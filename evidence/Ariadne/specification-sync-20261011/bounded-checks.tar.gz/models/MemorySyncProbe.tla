---------------- MODULE MemorySyncProbe ----------------
EXTENDS AriadneMemoryRefinement
ProbeSafety ==
  /\ (LET r == Inverse(Fact("exact",15,2,<<>>),Transfer("copy",1)) IN /\ r.after = Fact("exact",15,2,<<>>) /\ r.represented = TRUE /\ r.before = {2} /\ r.conflict = FALSE /\ r.boundary = "")
  /\ (LET r == Inverse(Fact("exact",15,2,<<>>),Transfer("add",1)) IN /\ r.after = Fact("exact",15,2,<<>>) /\ r.represented = TRUE /\ r.before = {1} /\ r.conflict = FALSE /\ r.boundary = "")
  /\ (LET r == Inverse(Fact("exact",15,2,<<>>),Transfer("sub",1)) IN /\ r.after = Fact("exact",15,2,<<>>) /\ r.represented = TRUE /\ r.before = {3} /\ r.conflict = FALSE /\ r.boundary = "")
  /\ (LET r == Inverse(Fact("exact",15,2,<<>>),Transfer("and",1)) IN /\ r.after = Fact("exact",15,2,<<>>) /\ r.represented = FALSE /\ r.before = {} /\ r.conflict = TRUE /\ r.boundary = "inconsistent-predecessor-constraints")
  /\ (LET r == Inverse(Fact("exact",15,2,<<>>),Transfer("constant",1)) IN /\ r.after = Fact("exact",15,2,<<>>) /\ r.represented = FALSE /\ r.before = {} /\ r.conflict = TRUE /\ r.boundary = "inconsistent-predecessor-constraints")
  /\ (LET r == Inverse(Fact("exact",15,0,<<>>),Transfer("and",0)) IN /\ r.after = Fact("exact",15,0,<<>>) /\ r.represented = TRUE /\ r.before = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15} /\ r.conflict = FALSE /\ r.boundary = "information-erasure")
  /\ (LET r == Inverse(Fact("exact",15,2,<<>>),Transfer("and",3)) IN /\ r.after = Fact("exact",15,2,<<>>) /\ r.represented = TRUE /\ r.before = {2,6,10,14} /\ r.conflict = FALSE /\ r.boundary = "")
  /\ (LET r == Inverse(Fact("exact",15,3,<<>>),Transfer("constant",3)) IN /\ r.after = Fact("exact",15,3,<<>>) /\ r.represented = TRUE /\ r.before = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15} /\ r.conflict = FALSE /\ r.boundary = "information-erasure")
  /\ (LET r == Inverse(Fact("unknown",0,0,<<>>),Transfer("copy",1)) IN /\ r.after = Fact("unknown",0,0,<<>>) /\ r.represented = TRUE /\ r.before = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15} /\ r.conflict = FALSE /\ r.boundary = "no-useful-numerical-constraint")
  /\ (LET r == Inverse(Fact("unknown",0,0,<<>>),Transfer("add",1)) IN /\ r.after = Fact("unknown",0,0,<<>>) /\ r.represented = TRUE /\ r.before = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15} /\ r.conflict = FALSE /\ r.boundary = "no-useful-numerical-constraint")
  /\ (LET r == Inverse(Fact("unknown",0,0,<<>>),Transfer("sub",1)) IN /\ r.after = Fact("unknown",0,0,<<>>) /\ r.represented = TRUE /\ r.before = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15} /\ r.conflict = FALSE /\ r.boundary = "no-useful-numerical-constraint")
  /\ (LET r == Inverse(Fact("unknown",0,0,<<>>),Transfer("and",1)) IN /\ r.after = Fact("unknown",0,0,<<>>) /\ r.represented = TRUE /\ r.before = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15} /\ r.conflict = FALSE /\ r.boundary = "no-useful-numerical-constraint")
  /\ (LET r == Inverse(Fact("unknown",0,0,<<>>),Transfer("constant",1)) IN /\ r.after = Fact("unknown",0,0,<<>>) /\ r.represented = TRUE /\ r.before = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15} /\ r.conflict = FALSE /\ r.boundary = "no-useful-numerical-constraint")
  /\ (LET r == Inverse(Fact("constrained",3,2,<<>>),Transfer("copy",0)) IN /\ r.after = Fact("constrained",3,2,<<>>) /\ r.represented = TRUE /\ r.before = {2,6,10,14} /\ r.conflict = FALSE /\ r.boundary = "")
  /\ (LET r == Inverse(Fact("constrained",3,2,<<>>),Transfer("add",1)) IN /\ r.after = Fact("constrained",3,2,<<>>) /\ r.represented = TRUE /\ r.before = {1,5,9,13} /\ r.conflict = FALSE /\ r.boundary = "")
  /\ (LET r == Inverse(Fact("constrained",3,2,<<Transfer("add",1)>>),Transfer("and",15)) IN /\ r.after = Fact("constrained",3,2,<<Transfer("add",1)>>) /\ r.represented = TRUE /\ r.before = {1,5,9,13} /\ r.conflict = FALSE /\ r.boundary = "")
  /\ (LET r == Inverse(Fact("constrained",3,2,<<Transfer("add",1)>>),Transfer("and",3)) IN /\ r.after = Fact("constrained",3,2,<<Transfer("add",1)>>) /\ r.represented = FALSE /\ r.before = {} /\ r.conflict = FALSE /\ r.boundary = "unsupported-constraint-composition")
  /\ (LET r == Inverse(Fact("constrained",3,2,<<Transfer("add",1)>>),Transfer("and",0)) IN /\ r.after = Fact("constrained",3,2,<<Transfer("add",1)>>) /\ r.represented = FALSE /\ r.before = {} /\ r.conflict = FALSE /\ r.boundary = "unsupported-constraint-composition")
  /\ (LET r == Inverse(Fact("constrained",1,1,<<Transfer("add",1),Transfer("sub",15)>>),Transfer("add",1)) IN /\ r.after = Fact("constrained",1,1,<<Transfer("add",1),Transfer("sub",15)>>) /\ r.represented = FALSE /\ r.before = {} /\ r.conflict = FALSE /\ r.boundary = "constraint-expression-budget")
  /\ (LET r == Inverse(Fact("constrained",1,1,<<Transfer("add",1),Transfer("sub",15)>>),Transfer("copy",0)) IN /\ r.after = Fact("constrained",1,1,<<Transfer("add",1),Transfer("sub",15)>>) /\ r.represented = TRUE /\ r.before = {1,3,5,7,9,11,13,15} /\ r.conflict = FALSE /\ r.boundary = "")
  /\ (LET r == Inverse(Fact("constrained",3,2,<<Transfer("add",1)>>),Transfer("constant",1)) IN /\ r.after = Fact("constrained",3,2,<<Transfer("add",1)>>) /\ r.represented = TRUE /\ r.before = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15} /\ r.conflict = FALSE /\ r.boundary = "information-erasure")
  /\ (LET r == Inverse(Fact("constrained",3,2,<<Transfer("add",1)>>),Transfer("constant",2)) IN /\ r.after = Fact("constrained",3,2,<<Transfer("add",1)>>) /\ r.represented = FALSE /\ r.before = {} /\ r.conflict = TRUE /\ r.boundary = "inconsistent-predecessor-constraints")
  /\ CandidateSafety
  /\ ~Disjoint(15,4,1,2) /\ Disjoint(15,4,8,2)
========================================================
