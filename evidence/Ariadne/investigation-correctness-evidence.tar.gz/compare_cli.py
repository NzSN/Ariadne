from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/home/nzsn/Repos/Ariadne');work=Path(__file__).parent
phase=sys.argv[1]
cases=[('linux','tests/input/fixtures/stage_b_linux.dmp','0x401000','0x401006'),('windows','tests/input/fixtures/stage_b_windows.dmp','0x7ff700001000','0x7ff700001006'),('not','tests/input/fixtures/bap_precision_linux.dmp','0x401000','0x401006'),('real-linux','tmp/priority1/chromium-member-uaf.dmp','0x566817922dc5','0x566817922e42')]
record={}
for label,dump,entry,site in cases:
 out=work/phase/label;out.parent.mkdir(parents=True,exist_ok=True)
 cmd=[str(root/'target/release/ariadne-minidump'),str(root/dump),'--decoder-reference',str(root/'target/ariadne-llvm-mc'),'--entry',entry,'--explain-fault-address',site,'--memory-access','0','--output-dir',str(out)]
 r=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=120)
 assert r.returncode==0,(label,r.stdout,r.stderr)
 record[label]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir())}
 print(phase,label,'ok',flush=True)
(work/(phase+'-hashes.json')).write_text(json.dumps(record,indent=2)+'\n')
if phase=='after':
 assert record==json.loads((work/'before-hashes.json').read_text())
 print('All',sum(map(len,record.values())),'reports byte-identical')
