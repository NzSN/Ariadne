from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/home/nzsn/Repos/Ariadne');work=Path(__file__).parent/'budget-mutations';work.mkdir()
for name in ['tools/check_investigation.py','tools/measure_investigation.py','tools/investigation_budget.py','tools/test_investigation_budget.py','tools/rust_layout.py','evidence/Ariadne/priority-1-real-capture-case.json','evidence/Ariadne/priority-4-real-capture-case.json']:
 target=work/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,target)
path=work/'tools/investigation_budget.py';original=path.read_text()
test=work/'tools/test_investigation_budget.py';test_hash=hashlib.sha256(test.read_bytes()).hexdigest()
rows=[]
for name,old,new in [('baseline',None,None),('ignore-windows-budget','met = median <= WINDOWS_BUDGET_MS','met = True'),('trust-reported-median','median = statistics.median(samples)','median = record["elapsedMs"]["median"]')]:
 if old:assert original.count(old)==1
 path.write_text(original if old is None else original.replace(old,new))
 r=subprocess.run(['python3','-B','-m','unittest','discover','-s',str(work/'tools'),'-p','test_investigation_budget.py'],capture_output=True,text=True,cwd=work)
 text=r.stdout+r.stderr;(work/(name+'.log')).write_text(text)
 intended=(r.returncode==0 if old is None else r.returncode==1 and 'FAIL:' in text and 'ERROR:' not in text)
 assert intended,(name,text)
 rows.append({'case':name,'exitCode':r.returncode,'expectedOutcome':intended})
 print(name,'PASS',flush=True)
path.write_text(original)
assert hashlib.sha256(test.read_bytes()).hexdigest()==test_hash
(work/'report.json').write_text(json.dumps({'passed':True,'observerSha256':test_hash,'records':rows},indent=2)+'\n')
