#!/usr/bin/env python3
"""Retain the completed I5a run and verify its exact source-bound artifacts."""
import hashlib
import json
import re
import shutil
import tarfile
import tempfile
from pathlib import Path

ROOT = Path('/home/nzsn/Repos/Ariadne')
WORK = Path('/tmp/ariadne-i5a.6kbMqT')
ACCEPTANCE = Path('/tmp/ariadne-i5a-acceptance-m54o8got')
DESTINATION = ROOT / 'evidence/Ariadne'
ALLOWED = {'.json', '.jsonl', '.log', '.csv', '.txt', '.dot', '.time'}
EXCLUDED_PARTS = {'sut', 'target', '__pycache__', '.git'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


report_path = ACCEPTANCE / 'report.json'
report = json.loads(report_path.read_text())
assert report['passed'] and report['sourceFixtureAcceptancePassed']
assert report['sourcesStable'] and len(report['gates']) == 12
assert not report['controlledRealWindowsAcceptancePassed']
assert not report['originalWindowsI4AcceptancePassed']
source_hashes = {}


def check_sources(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {'sourceHashes', 'sourceSha256'} and isinstance(item, dict):
                for path, digest in item.items():
                    assert sha(ROOT / path) == digest, f'stale source: {path}'
                    assert path not in source_hashes or source_hashes[path] == digest
                    source_hashes[path] = digest
            else:
                check_sources(item)
    elif isinstance(value, list):
        for item in value:
            check_sources(item)


check_sources(report)
tool_hashes = {}
for record in [report, report['records']['measurements'],
               report['records']['investigation'],
               report['records']['investigation']['records']['workload']]:
    for name, digest in record['tools'].items():
        assert sha(ROOT / name) == digest, f'changed measured tool: {name}'
        assert name not in tool_hashes or tool_hashes[name] == digest
        tool_hashes[name] = digest
stage_e_tools = report['records']['investigation']['records']['stage-e']['tools']
for name, digest in {
    'target/ariadne-llvm-ir': stage_e_tools['nativeIRSha256'],
    'target/ariadne-llvm-mc': stage_e_tools['nativeMCSha256'],
    stage_e_tools['graphvizPath']: stage_e_tools['graphvizSha256'],
}.items():
    assert sha(ROOT / name) == digest, f'changed native tool: {name}'
    tool_hashes[name] = digest
stage = Path(tempfile.mkdtemp(prefix='ariadne-i5a-retained-'))
origin_paths = {}


def copy_file(source, name):
    source = Path(source)
    assert source.is_file() and not source.is_symlink(), source
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    target = stage / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert sha(target) == sha(source), name
    else:
        shutil.copyfile(source, target)
    origin_paths[str(source)] = name


def copy_artifacts(directory, name, recursive=True):
    directory = Path(directory)
    files = directory.rglob('*') if recursive else directory.iterdir()
    for path in sorted(files):
        relative = path.relative_to(directory)
        if (path.is_file() and not set(relative.parts) & EXCLUDED_PARTS
                and path.suffix in ALLOWED):
            copy_file(path, str(Path(name) / relative))


# Each runner prints its artifact directory or final report into its parent log.
pending = [(ACCEPTANCE, 'acceptance')]
visited = set()
while pending:
    directory, name = pending.pop(0)
    if directory in visited:
        continue
    visited.add(directory)
    copy_artifacts(directory, name)
    for log in directory.glob('*.log'):
        for match in re.finditer(r'(?m)^.*(?:[Aa]rtifacts:|Report:)\s+(/\S+)', log.read_text()):
            path = Path(match.group(1))
            child = path.parent if path.is_file() else path
            if child.is_dir() and child.parent == Path('/tmp') and child.name.startswith('ariadne-'):
                pending.append((child, 'nested/' + child.name))

# The generated replay runner records its work directory in the embedded result.
replay = report['records']['investigation']['records']['stage-e']['replay']
assert replay['passed']
copy_artifacts(Path(replay['logs']), 'stage-e-replay')
copy_file(ROOT / 'mbt/stage-e/results/latest.json', 'stage-e-replay/latest.json')
assert json.loads((stage / 'stage-e-replay/latest.json').read_text()) == replay

copy_artifacts(WORK / 'before', 'before')
for name in ['before-hashes.json', 'pilot.csv', 'pilot-cli.json']:
    copy_file(WORK / name, 'pilot-and-baseline/' + name)
copy_file(ROOT / 'tests/input/fixtures/i5a/performance.json', 'pilot-and-baseline/performance-contract.json')
copy_file(WORK / 'acceptance-final.log', 'acceptance-console.log')
copy_file(Path(__file__), 'retain_i5a.py')

# Retain the source inventory from every nested campaign, never external raw dumps.
for name, digest in sorted(source_hashes.items()):
    path = Path(name)
    assert not path.is_absolute() and '..' not in path.parts, name
    assert not name.startswith('tmp/'), name
    copy_file(ROOT / name, 'sources/' + name)
    assert sha(stage / 'sources' / name) == digest

(stage / 'README.txt').write_text(
    'I5a source/fixture acceptance, 2026-10-03 working tree based on c9eb4c5.\n'
    'The original root and nested records retain their source/tool identities.\n'
    'The source snapshot matches the union of the nested source inventories.\n'
    'Pilot measurements are observations and are not acceptance evidence.\n'
    'Only synthetic test dumps are included in sources/tests; real dumps stay external.\n'
    'Controlled real Windows I5a and original-Windows I4 remain unqualified.\n'
)
entries = {
    str(path.relative_to(stage)): sha(path)
    for path in sorted(stage.rglob('*')) if path.is_file()
}
archive = DESTINATION / 'i5a-evidence.tar.gz'
manifest_path = DESTINATION / 'i5a-evidence-manifest.json'
validation_path = DESTINATION / 'i5a-validation.json'
assert not any(p.exists() for p in [archive, manifest_path, validation_path])
with tarfile.open(archive, 'w:gz') as tar:
    for name in entries:
        tar.add(stage / name, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    actual = {}
    for member in tar.getmembers():
        assert member.isfile()
        actual[member.name] = hashlib.sha256(tar.extractfile(member).read()).hexdigest()
    assert actual == entries
shutil.copyfile(report_path, validation_path)
manifest = {
    'schema': 'ariadne.evidence-manifest/v1',
    'archive': archive.name,
    'sha256': sha(archive),
    'bytes': archive.stat().st_size,
    'validationRecord': validation_path.name,
    'validationRecordSha256': sha(validation_path),
    'sourceInventoryCount': len(source_hashes),
    'verifiedToolHashes': tool_hashes,
    'entries': entries,
    'originalPaths': origin_paths,
    'scope': 'I5a source/fixture qualification and fresh investigation/Stage E/minidump regression. Synthetic fixtures and derived reports only; no real Windows or original-Windows I4 qualification.',
}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
check_sources(report)
print(json.dumps({
    'retainedDirectory': str(stage),
    'archiveBytes': archive.stat().st_size,
    'archiveEntries': len(entries),
    'verifiedSourceHashes': len(source_hashes),
    'validationRecord': str(validation_path),
    'manifest': str(manifest_path),
}, indent=2))
