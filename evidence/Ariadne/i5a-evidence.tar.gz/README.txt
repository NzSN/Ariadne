I5a source/fixture acceptance, 2026-10-03 working tree based on c9eb4c5.
The original root and nested records retain their source/tool identities.
The source snapshot matches the union of the nested source inventories.
Pilot measurements are observations and are not acceptance evidence.
Only synthetic test dumps are included in sources/tests; real dumps stay external.
Controlled real Windows I5a and original-Windows I4 remain unqualified.
