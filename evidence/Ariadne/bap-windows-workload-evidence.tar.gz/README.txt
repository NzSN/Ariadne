Current BAP implementation/corpus qualification only.
Full Stage 1 exit and the Stage 2 prerequisite remain false: original Windows capture unavailable.
The final aggregate passes; initial-incomplete-aggregate is historical diagnostic evidence,
with a missing Graphviz environment and source edits during its parent run.
Its independently stable model/mutation/workload components were source/tool-verified for reuse.
Stage E was retained from the I5a campaign after complete source/tool identity checks.
Controlled tests use stubbed evidence; supplemental real Windows demos each decode two instructions.
Neither substitutes for the original Windows 98-instruction workload. No raw captures or executables retained.
