"""Retain the final BAP campaign; raw captures and executable files are excluded."""
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import check_bap_semantics as gate
import check_bap_model as model
import check_bap_mutations as mutations
import check_stage_e as stage_e
import measure_bap as workloads


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_sources(record, expected):
    assert record['passed'] is True and record['sourcesStable'] is True
    assert record['sourceHashes'] == expected()


final = Path(sys.argv[1])
first = Path(sys.argv[2])
data = json.loads((final / 'report.json').read_text())
verify_sources(data, gate.sources)
for key, module in [('model', model), ('mutation', mutations),
                    ('workload', workloads), ('stage-e', stage_e)]:
    verify_sources(data['records'][key], module.sources)
gate.validate_workload_bindings(data['records']['workload'])
assert data['records']['model']['observerSha256'] == sha(ROOT / 'target/release/bap-model-case')
stage = data['records']['stage-e']
assert stage['tools']['nativeIRSha256'] == sha(ROOT / 'target/ariadne-llvm-ir')
assert stage['tools']['nativeMCSha256'] == sha(ROOT / 'target/ariadne-llvm-mc')
assert stage['tools']['graphvizSha256'] == sha(stage['tools']['graphvizPath'])
assert data['graphviz']['sha256'] == sha(data['graphviz']['path'])
assert not data['stage1ExitPassed'] and not data['stage2PrerequisiteSatisfied']
assert data['windows98Qualification']['status'] == 'unavailable'
assert all(row['exitCode'] == 0 for row in data['gates'])

entries = {}


def add(path, name):
    path = Path(path)
    assert path.is_file(), path
    assert path.suffix.lower() not in ('.dmp', '.mdmp', '.exe', '.dll', '.so')
    assert name not in entries, name
    entries[name] = path.read_bytes()


for path in sorted(final.glob('*')):
    if path.is_file():
        add(path, 'acceptance/' + path.name)
for path in sorted(first.glob('*.log')):
    add(path, 'initial-incomplete-aggregate/' + path.name)
add(first / 'report.json', 'initial-incomplete-aggregate/report.json')
for key in ('model', 'mutation', 'workload'):
    lines = (first / (key + '.log')).read_text().splitlines()
    report = Path(next(line[8:] for line in lines if line.startswith('Report: ')))
    assert json.loads(report.read_text()) == data['records'][key]
    for path in sorted(report.parent.rglob('*')):
        if not path.is_file() or 'sut' in path.relative_to(report.parent).parts:
            continue
        if path.suffix in ('.json', '.log', '.csv', '.txt', '.dot', '.time', '.tla', '.cfg'):
            add(path, key + '/' + str(path.relative_to(report.parent)))
base = Path(__file__).parent
add(base / 'stage-e-current.json', 'reused-stage-e/report.json')
add(base / 'retention-readiness.json', 'campaign-scope.json')
origin = ROOT / 'evidence/Ariadne/i5a-evidence-manifest.json'
origin_data = json.loads(origin.read_text())
assert sha(origin.parent / origin_data['archive']) == origin_data['sha256']
assert sha(origin.parent / origin_data['validationRecord']) == origin_data['validationRecordSha256']
entries['reused-stage-e/origin.json'] = (json.dumps({
    'recordOrigin': 'evidence/Ariadne/i5a-validation.json: records.investigation.records.stage-e',
    'originManifest': 'evidence/Ariadne/i5a-evidence-manifest.json',
    'originManifestSha256': sha(origin),
    'originArchive': origin_data['archive'],
    'originArchiveSha256': origin_data['sha256'],
    'reuse': 'Complete current source inventory, native IR/MC and Graphviz identities verified; not freshly rerun.'
}, indent=2) + '\n').encode()
smoke = json.loads((base / 'smoke.json').read_text())
for path, digest in smoke['tools'].items():
    assert sha(ROOT / path) == digest
for name in ('smoke.json', 'partial.csv', 'full.csv', 'partial.stderr.log', 'full.stderr.log'):
    add(base / name, 'supplementary-windows-input/' + name)
for path in sorted(Path('/tmp/ariadne-bap-windows-fix').glob('*')):
    if path.is_file():
        add(path, 'controlled-regressions/' + path.name)
add(base / 'acceptance.log', 'initial-console.log')
add(base / 'acceptance-final.log', 'acceptance-console.log')
add(Path(__file__), 'retention-script.py')
entries['README.txt'] = b'''Current BAP implementation/corpus qualification only.
Full Stage 1 exit and the Stage 2 prerequisite remain false: original Windows capture unavailable.
The final aggregate passes; initial-incomplete-aggregate is historical diagnostic evidence,
with a missing Graphviz environment and source edits during its parent run.
Its independently stable model/mutation/workload components were source/tool-verified for reuse.
Stage E was retained from the I5a campaign after complete source/tool identity checks.
Controlled tests use stubbed evidence; supplemental real Windows demos each decode two instructions.
Neither substitutes for the original Windows 98-instruction workload. No raw captures or executables retained.
'''
dest = ROOT / 'evidence/Ariadne'
record_path = dest / 'bap-windows-workload-validation.json'
record_path.write_bytes((final / 'report.json').read_bytes())
archive = dest / 'bap-windows-workload-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, contents in sorted(entries.items()):
        info = tarfile.TarInfo(name)
        info.size = len(contents)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(contents))
manifest = dict(schema='ariadne.evidence-manifest/v1', archive=archive.name,
                sha256=sha(archive), bytes=archive.stat().st_size,
                validationRecord=record_path.name, validationRecordSha256=sha(record_path),
                sourceInventoryCount=len(data['sourceHashes']),
                entries={name: hashlib.sha256(contents).hexdigest() for name, contents in sorted(entries.items())})
with tarfile.open(archive) as tar:
    assert {member.name for member in tar.getmembers()} == set(manifest['entries'])
    for member in tar.getmembers():
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == manifest['entries'][member.name]
(dest / 'bap-windows-workload-evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({key: manifest[key] for key in ('archive', 'bytes', 'sha256', 'sourceInventoryCount')}))
print('Verified archive entries:', len(entries))
