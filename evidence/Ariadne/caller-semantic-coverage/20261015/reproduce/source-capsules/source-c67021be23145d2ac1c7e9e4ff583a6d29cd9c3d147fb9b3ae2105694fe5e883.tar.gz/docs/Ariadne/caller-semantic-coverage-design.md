# Caller normal-flow coverage: exception exits and guarded MOVAPS loads

## Context and follow-up

**Status.** Diagnosed and designed on 2026-10-15 against `3176d44`; implementation and qualification are pending under the [S0–S6 plan](../../Plans/caller-semantic-coverage.md). The four-shape public preparation probe is RED on the unchanged qualified runtime. This document closes no runtime gate by itself.

**Why this document exists.** [Loop closure](guarded-target-resolution-design.md#dated-loop-delivery-and-publication-correction--2026-10-15) completes DA09/DADD but leaves 30 caller guard barriers: 27 INT3 sites, one UD2, one UD1 and one MOVAPS load. This is item 2 of the remaining-blocker inventory.

**What this document establishes.** A narrow control-only terminal certificate, exact guarded-load recognition, versioned replay and acceptance gates that preserve the [BAP trust contract](semantic-assurance.md). It does not add LLVM-derived effects or a general exception interpreter.

**Where to go next.** Read the [guard contract](justified-branch-pruning-design.md), [composition contract](guarded-target-resolution-design.md), [formal guide](../../Specs/README.md) and execution plan. The [frame-path ledger](../../Plans/frame-path-enumeration.md) retains the separate positive-listing gate.

**What remains unresolved.** Normal-flow closure does not prove alignment, exception-handler behavior, executed history or full frame paths. The final original-dump retry must report these independently. Callee indirect targets and its work limits remain separate work.

## Reproduced facts

The unchanged source capsule is `5cd406c5181d131679a60af15f53edcabecfe056144e40b5785bc37ce1d010ee`. Remote probe `caller-barriers-20261015T060803` exercises public `Backend::prepare` and `FileSnapshot::prepare_with_bap_guard_admission` on four captured prefixes. It returns `selected_barriers_closed=false`, lists all four sites, and verifies that all 877 qualified files are unchanged. Earlier standalone-driver compilation failures receive no runtime credit.

Remote raw probe `raw-bap-20261015T061711` records the qualified helper's exact output. A diagnostic copy adds only the assembly getter; every other semantic field matches the qualified helper across nine queries. [Captured cases](../../tests/bap/fixtures/caller-coverage/dump-four-shapes.json) and [raw observations](../../tests/bap/fixtures/caller-coverage/raw-bap-observations.json) preserve provenance.

| Shape and representative VA | Exact observation | Cause to correct |
| --- | --- | --- |
| INT3, `0x00007ff77440b30d` | `cc`; BAP singleton `Exception(3)`; LLVM currently labels INT instructions unsupported | Narrow reference classification and checked terminal admission are absent. |
| UD2, `0x00007ff77440b753` | `0f0b`; LLVM terminal; BAP opcode `TRAP`, two consumed bytes and empty BIL | The adapter rejects all Stops; an empty lift is not ordinary semantics. |
| UD1, `0x00007ff77440b0e0` | LLVM consumes `670fb94012`, length 5; BAP consumes `670fb9`, length 3, opcode `UD2B`, empty BIL | Pinned BAP treats `0fb9` as the older two-byte form. Removing `67` still gives the discrepancy. |
| MOVAPS load, `0x00007ff7744035c9` | `0f28b42440020000`; YMM6 merge/load128 followed by the alignment check and `Exception(13)` | The guard recognizer accepts only the `0f29` store form. |

All BAP control-property booleans are false for these four shapes. The coordinator also labels every Stop a barrier, while Rust/native guard replay independently rejects unreviewed exceptional BIL. Fixing only the initial decoder classification cannot close coverage.

## Existing local scope and the new terminal certificate

`Ariadne.tla` already excludes exception/unwind execution and makes Return/Stop end local flow. A certificate means only:

```text
captured bytes and checked source facts establish a supported exception exit
normal_successors(site) = {}
exception-handler/debugger resumption is outside this local-normal-flow scope
```

It is not a premise that an exception handler never resumes. Query/profile/report identities must bind the explicit scope `local-normal-completion/v1`, and reports retain `exception-exit` and `exception-resumption-outside-local-scope`. They cannot turn normal-flow closure into whole-machine completeness or a historical no-path conclusion.

Intel specifies that UD instructions raise #UD and that legacy MOVAPS memory forms require 16-byte alignment. INT3 transfers to the interrupt/exception machinery. These architectural facts justify the narrow control/guard rules; they do not establish how this process handled an exception. [Intel Volume 2B, UD and MOVAPS](https://cdrdv2.intel.com/v1/dl/getContent/671241), [Intel Volume 2A, INT3](https://www.intel.com/content/dam/www/public/us/en/documents/manuals/64-ia-32-architectures-software-developer-vol-2a-manual.pdf).

Use one private terminal-control module shared by preparation and Rust replay. Its interface recognizes and independently validates a source-bound receipt. It must receive the complete captured instruction span, original BAP AST and consumed bytes/status/opcode/properties, and independent decoder facts. Recognition returns a certificate or declines; it cannot grant ordinary continuation or numerical/register effects.

First supported forms:

- INT3: exact `cc`, singleton BAP `Exception(3)`, matching one-byte source and reference facts. Other interrupts and prefixed forms remain unsupported.
- UD2: exact `0f0b`, matching two-byte `TRAP` observations, empty BIL and independently checked terminal reference facts. Empty BIL on another opcode remains unsupported.
- UD1: reviewed `0fb9 /r` encodings, optionally one `67` address-size prefix, with complete ModR/M, optional SIB and displacement validation. No other prefixes are admitted. The captured full span must match the reference decoder. Preserve the pinned BAP `UD2B` opcode-only consumed extent and its disagreement explicitly. This is a control-only certificate; never fabricate a BAP `Exception(6)` or globally waive consumed-byte agreement.

Every admitted terminal becomes a decodable, complete Stop with empty normal successor sets. Retain conservative all-location uses/may-defs, no must-defs, and unsupported exceptional effects. Keep original bytes, BIL and decoder observations unchanged. Only independently validated terminal receipts can remove a candidate coverage barrier; every unmatched Stop remains a barrier.

The native checker independently replays the byte/span/AST/control rule. It rejects forged ordinary Stops, mismatched source spans, additional BIL effects, conditional exceptions with a normal arm, unknown rules and missing/tampered scope. LLVM remains a decode/control reference and supplies no effects.

## Guarded MOVAPS load

Extend the existing exact recognizer with a load operation. Match the reviewed legacy RSP-relative `0f28` encoding, destination bank, preserved high 128 bits of that same YMM bank, and the 128-bit load from the address tested by the existing alignment predicate. Require the exact empty aligned arm and singleton `Exception(13)` alternative. Reject extra effects and other prefixes or vector families.

Candidate discovery may use an independently checked RSP/scalar identity over the candidate normal transition. It commits no vector or memory-read effect. Only an aligned verdict authorizes projection of the retained BAP normal AST; unknown/misaligned outcomes keep their current stop and residual. Coarse vector projection preserves old origins and introduces no vector must-defs. Page/protection and other ordinary-memory fault limits remain unchanged.

Keep the public `PendingGuard` shape where practical; use operation-specific receipt rules/digests so load/store evidence cannot be exchanged. The existing scalar target extractor already ignores YMM-only writes and the nonjump exception conditional. Avoid changing target-resolver/loop-checker source merely to support the load.

## Versioned contracts and compatibility

Freeze the [legacy sources and identities](../../tests/bap/fixtures/caller-coverage/legacy-manifest.json) before edits. Shared validation may use explicit version policies; legacy recognition, coverage and normal selection must retain the old store-only contract. Old profiles must not authorize terminal evidence or load guards.

| Surface | Retained generation | New generation |
| --- | --- | --- |
| Guard report/profile/model | v1 / `bap-guard-admission-v1` / predicate v1 | v2 / `bap-guard-admission-v2` / predicate v2 |
| Guarded semantic producer | `bap-bit-provenance-v7` | `bap-bit-provenance-v8` |
| Native guard-only input | `captured-guarded-input/v1` | `captured-guarded-input/v2` |
| Combined native/composition | v1 and v2 | v3 |
| Guard-only minidump/explanation/frame | v3 / v2 / v2 | v6 / v5 / v5 |
| Combined minidump/explanation/frame | v4-v5 / v3-v4 / v3-v4 | v7 / v6 / v6 |

Default unguarded projection v6 and rooted target-only v1 retain their contract. Local target report v3/local-v2 and loop engine `afc1b4b…` remain unchanged if their source files remain unchanged.

New guard inputs carry one nonnull, tagged normal-flow evidence field containing the scope and sorted terminal receipts, even when the receipt list is empty. Legacy guard input must omit it entirely; explicit null and unsupported tags reject. Bind it to intent, candidate graph, epochs and final request. Never erase evidence or rebind old hashes to new rules.

Legacy guard checker/model identities are `076b8a3fb6f776e53ea99336854c1a793b8658874c153f4ddd2e32c54128ce7d` / `10e870b21691946cd7985ff7d33819a8a58e4fea202ae6d2e771214b997f5bc9`. Retained composition v2 identities are `605fb57d42e755b7fee75511f66e6ad864a16c303bbf5ffb5bad8855c7d05675` / `dd277b844376234cce199ecae9e7bc9eee04dfa69390d2320c2349b4f11b6cb4`. Keep composition v1's already-frozen path.

The new guard checker identity must bind both guard and terminal-checker sources. The new composition checker/model identities additionally bind the new guard contract. Native metadata advertises legacy and current pairs separately. Actual saved guard-only reports, 2026-10-14 combined reports and 2026-10-15 loop reports must replay under their original contracts after the upgrade.

## Formal and acceptance boundary

Extend predicate-admission authority before runtime implementation to distinguish certified normal terminals, pending load/store guards and coverage barriers. Model stale epochs, invalid scope/evidence, late edges, forbidden terminal successors and unknown alignment. Existing core Stop semantics and target/loop premise interfaces remain authoritative and unchanged. Finite checks do not prove universal refinement or an inter-model coupling theorem.

The four-shape feedback must become green without assuming RSP alignment. Full acceptance requires all 30 original caller sites to stop being unresolved candidate barriers under the declared normal-flow contract, every original INT3 site to have checked terminal evidence, and no replacement unaccounted barrier. Preserve all nine original target sets, DA09/DADD completeness, entry roots and captured bytes. Re-run the byte-identical dump and both native/Rust full-state comparisons.

Report initial MOVAPS admission, the later MOVAPS-load verdict, new discovery, callee barriers and frame-path availability separately. A successful frame listing is not a prerequisite for this narrower semantic-coverage gate.
