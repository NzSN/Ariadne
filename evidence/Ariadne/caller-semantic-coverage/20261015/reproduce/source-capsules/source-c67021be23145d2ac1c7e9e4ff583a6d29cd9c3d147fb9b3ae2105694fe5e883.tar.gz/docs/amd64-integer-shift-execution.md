# AMD64 shift and rotate execution binding

## Context and follow-up

> **Specification removal (2026-10-11).** The ISA specifications, coverage
> inventories and associated checkers described here have been removed.
> Their links point to an immutable Git archive; the commands below require
> that historical checkout. See the [current assurance boundary](Ariadne/semantic-assurance.md#dependency-audit-and-retained-references).

**Status.** Retired ISA research; links below explain historical dependencies, not an active backlog.

**Why this document exists.** Pure kernels need operand snapshots and register writes. The motivating contract is [Historical motivation](amd64-integer-semantics.md).

**What this document establishes.** The body relations bind shift/rotate forms to pre-state operand reads and register effects; memory instances depend on additional access composition.

**Where to go next.**

- [Related historical component](amd64-machine-access.md) — describes the memory-access composition absent from register-only instances.
- [Retirement and current boundary](Ariadne/semantic-assurance.md) — ends the instruction-step objective without declaring its proof gaps solved.

**What remains unresolved.** This research is retired. Missing architectural bindings or proof obligations below remain historical gaps, not active release tasks or solved claims. Production instruction effects now follow the BAP trust boundary.

For the wider context, see the optional [documentation map](documentation-map.md).

> **Retired 2026-10-02.** This document and its ISA proof/profile artifacts
> are historical reference, outside active development and qualification.
> Milestones and commands below describe the former research track. See the
> [current semantic assurance decision](Ariadne/semantic-assurance.md).

This checkpoint binds all 116 pinned Volume 3 shift and rotate rows to concrete
CPU register effects. The source evidence and grouped form IDs are recorded in
`Specs/AMD64/integer-shift-form-supplement.json`. Original reg/mem alternatives
remain visible. A register instance executes; a memory instance returns
`modeling-unavailable` until MachineAccess provides resolved bytes and events.

Every operand is read from the pre-state before any write. This covers `SHL
CL,CL`, overlapping SHLD/SHRD operands, and BMI2 instructions whose destination,
source and count name the same register. A masked legacy count of zero skips the
destination and flag writes entirely. BMI2 instructions still write their
separate destination when their masked count is zero.

Legacy counts use five bits, or six for a 64-bit operand. Rotate value selection
uses the effective ring count while flag definedness uses the masked count.
SHLD/SHRD keep relational destinations and flags when the masked count exceeds
the operand width. BMI2 forms require protected, compatibility or long mode,
the BMI2 feature, `VEX.L=0`, and a `VEX.W` value matching the 32/64-bit row.

Validation combines Lean build and axiom audit, Snowcat typechecking, and a TLC
fixture covering all form bindings, source/destination aliasing, count zero,
ROL counts 8 and 9, an RCL full-ring count, two distinct SHLD16 oversize
destinations, and BMI2 feature/mode/encoding gates.
