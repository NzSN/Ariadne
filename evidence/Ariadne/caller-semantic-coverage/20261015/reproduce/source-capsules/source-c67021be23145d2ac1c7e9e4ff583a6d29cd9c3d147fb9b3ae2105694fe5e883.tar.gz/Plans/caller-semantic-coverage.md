# Close caller semantic-coverage barriers

## Context and follow-up

**Status.** S0 diagnosis and contract freezing complete; S1–S6 pending, 2026-10-15. The [canonical design](../docs/Ariadne/caller-semantic-coverage-design.md) owns the semantics and versions. This is the next task after the [completed loop plan](completed/loop-aware-target-resolution.md).

**Why this document exists.** [Original-dump probe `051409`](../evidence/Ariadne/loop-aware-target-resolution/20261015/artifacts/dump-20261015T051409/probe-summary.json) closes both cyclic jump certificates but leaves 30 caller barriers. Remote four-shape probe `060803` reproduces each instruction-class failure through the actual public preparation path.

**What this document establishes.** Execution order, ownership, independent negative controls and remote gates for item 2 of the blocker inventory.

**Where to go next.** Read the canonical design, the [guard contract](../docs/Ariadne/justified-branch-pruning-design.md), [BAP input interface](../docs/Ariadne/file-reader-design.md#public-interface) and [formal guide](../Specs/README.md). Raw new evidence belongs under `evidence/Ariadne/caller-semantic-coverage/20261015/`.

**What remains unresolved.** No production correction is qualified yet. Normal-flow exception exits do not establish handler behavior or historical execution. MOVAPS truth, callee work limits and full frame paths remain independent gates.

## Stages and ownership

Workers are not alone. Preserve unrelated edits and frozen evidence; coordinate shared types and identities before touching caller-owned files. Stage dependencies are evidence gates, not additional approval questions. All compilation, native helpers, models, replay, mutations and dump execution run in remote Windows WSL.

| Stage | Owner and files | Dependency | Acceptance |
| --- | --- | --- | --- |
| S0 — diagnose and freeze | Root/evidence owner; `tests/bap/fixtures/caller-coverage/`, canonical design, this plan | Current qualified baseline | Four actual RED cases; exact BAP/LLVM span diagnosis; original source/model/guard/composition identities frozen. |
| S1 — model and oracle | Model owner; `Specs/AriadnePredicateAdmission.tla`, new configs, checker and independent fixtures | S0 | Authority distinguishes normal terminals, unknown Stops and load/store guards; positive, invalid-evidence and stale-epoch finite controls pass before runtime acceptance. |
| S2 — Rust recognition and proof | Rust owner; private terminal module, `src/bap/guard_admission.rs`, `src/bap/prepare.rs`, required module exports, `native/llvm_mc/decode.cpp`, focused tests | S1 contract | Narrow terminal rules; conservative effects; exact MOVAPS load; legacy guard policy; replay rejects malformed bytes/AST/span/scope. Default unguarded semantics preserved. |
| S3 — native admission | Native owner; `native/bap-core/` terminal module, guard/capture/composition/main/build integration and native controls | S1 + frozen S2 wire | Independent source replay, versioned capability/legacy policies and strict new/current identities; no unsupported downgrade. |
| S4 — composition and consumers | Integration owner; `src/input/materialize.rs`, `src/bap/composition.rs`, core protocol/session/adapter and input/investigation/report consumers, integration tests | S2 + S3 | One coordinator; exact full graph binding including Stop endpoints; qualified terminals excluded from barriers only after validation; complete source/proof retention; actual old reports replay unchanged. |
| S5 — qualify | Root + independent reviewers; isolated remote source/helper/replay/mutation outputs and source/tool manifests | S4 | Applicable root tests, focused/native controls, model/oracle, behavioral mutations and 330 generated regression observations pass on exact sources. |
| S6 — original dump and delivery | Root/evidence owner; byte-identical frame-pair retry, caller barrier audit, docs/checkpoints | S5 | Original 30 barriers handled under explicit normal-flow scope; all original target facts preserved; both full native/Rust requests and states match; remaining guards/path outcomes reported honestly. |

## Required controls

- Actual INT3, UD2, UD1 and MOVAPS-load captured shapes; all 27 original INT3 sites; retain the exact UD1 3-byte versus 5-byte disagreement.
- Empty BIL on ordinary opcodes, fake terminal NOP/CLC, conditional exception with normal continuation, extra effects, wrong exception number, unknown rule, missing scope/exception-exit annotation, malformed/truncated bytes, unsupported prefixes and mismatched spans.
- UD1 ModR/M/SIB/displacement boundaries; no generic decoder-disagreement bypass and no fabricated BAP effects.
- MOVAPS load/store destination/direction, high-half preservation, width, address and predicate-polarity negatives; unknown/misaligned keeps a stop; no load/vector effect before proved alignment.
- Every terminal has no normal successors and no must-defs; unsupported Stops remain barriers. Handler resumption is outside the stated scope and never imported as a normal incoming fact.
- Stale candidate epochs, completeness-only changes, late roots/edges, source stripping and profile/hash downgrade.
- Actual guard-only legacy report replay; actual combined v1 and v2 minidump/frame reports; old-helper capability rejection before processing a new profile.
- At least one behavioral mutation per critical rule: bytes/extent binding, terminal-source match, no-successor/scope check, guarded-load shape, proof-gated effect selection and legacy-version policy. Compile failures and timeouts earn no credit.

## Remote qualification

Run the affected cases plus root format/default/core-only/Clippy/layout checks; native capture/composition/frame/report suites; predicate, composition, target and loop models; independent oracle; isolated targeted mutations; generated core/stateflow replay and original dump. Do not build locally. Local document and whitespace checks are permitted.

Use task-private source and build directories. Freeze and verify source files, helper/runtime/decoder identities, exact budgets, original dump SHA, command lines and output. Capture-only precedence, semantic VAs, existing entry roots and explicit uncertainty remain invariants. Preserve earlier failed driver attempts separately from actual RED/runtime results.

Current fast feedback command, using the qualified baseline and retained source-bound fixtures:

```sh
r_windev ':; MSYS_NO_PATHCONV=1 wsl.exe -d Ubuntu -u root -- bash /mnt/d/ariadne-caller-barriers-20261015-run-feedback.sh'
```

The confirmed RED run is `/loop-work/evidence/caller-barriers-20261015T060803`: exit 1, feedback present, four selected barriers, all 877 source files unchanged. Freeze a new source capsule and rebuild affected helpers before interpreting any later green result as implementation evidence.

## Completion boundary

S6 closes caller normal-flow semantic coverage, not all exception behavior, initial/later MOVAPS truth or full frame paths. Update the blocker inventory with exact remaining reasons, archive this plan only after its scoped gates pass, and retain the design's direct link to the completed execution record. No commit, push or deployment is part of this task unless requested.
